"""
VA QC App - Phase 1: Foundation
FastAPI web app for valve tracking
"""
from fastapi import FastAPI, Request, Form, HTTPException, Depends, status
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware
from datetime import datetime, timedelta
import bcrypt
import json
from typing import Optional

from config import SECRET_KEY, USERS, APP_NAME
from google_sheets import ValveDataStore

app = FastAPI(title=APP_NAME, version="1.0.0")

# Session middleware for login
app.add_middleware(
    SessionMiddleware,
    secret_key=SECRET_KEY,
    max_age=3600 * 8  # 8 hours
)

# Static files and templates
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verify password against bcrypt hash"""
    return bcrypt.checkpw(plain_password.encode(), hashed_password.encode())


def get_current_user(request: Request) -> Optional[dict]:
    """Get current user from session"""
    user = request.session.get("user")
    if user:
        return user
    return None


def require_login(request: Request):
    """Dependency to require login"""
    user = get_current_user(request)
    if not user:
        raise HTTPException(status_code=302, headers={"Location": "/login"})
    return user


@app.get("/", response_class=HTMLResponse)
async def root(request: Request):
    """Root - redirect to login or dashboard"""
    user = get_current_user(request)
    if user:
        return RedirectResponse(url="/dashboard", status_code=302)
    return RedirectResponse(url="/login", status_code=302)


@app.get("/login", response_class=HTMLResponse)
async def login_page(request: Request, error: str = None):
    """Login page"""
    return templates.TemplateResponse("login.html", {
        "request": request,
        "error": error,
        "app_name": APP_NAME
    })


@app.post("/login")
async def login(request: Request, username: str = Form(...), password: str = Form(...)):
    """Handle login"""
    user = USERS.get(username.lower())
    
    if not user or not verify_password(password, user["password"]):
        return templates.TemplateResponse("login.html", {
            "request": request,
            "error": "Invalid username or password",
            "app_name": APP_NAME
        })
    
    # Set session
    request.session["user"] = {
        "username": username.lower(),
        "name": user["name"],
        "role": user["role"],
        "email": user["email"]
    }
    
    return RedirectResponse(url="/dashboard", status_code=302)


@app.get("/logout")
async def logout(request: Request):
    """Logout and clear session"""
    request.session.clear()
    return RedirectResponse(url="/login", status_code=302)


@app.get("/dashboard", response_class=HTMLResponse)
async def dashboard(request: Request, user: dict = Depends(require_login)):
    """Main dashboard - valve list"""
    try:
        store = ValveDataStore()
        valves = store.get_all_valves()
        error_msg = None
    except Exception as e:
        valves = []
        error_msg = str(e)
    
    # Calculate counts
    in_progress = [v for v in valves if v.get('Status', '') in ['Received', 'In Stripped', 'In Before Assembly', 'In Final']]
    complete = [v for v in valves if v.get('Status', '') == 'Complete']
    
    return templates.TemplateResponse("dashboard.html", {
        "request": request,
        "user": user,
        "valves": valves,
        "in_progress_count": len(in_progress),
        "complete_count": len(complete),
        "app_name": APP_NAME,
        "error": error_msg
    })


@app.get("/valve/{job_number}", response_class=HTMLResponse)
async def valve_detail(request: Request, job_number: str, user: dict = Depends(require_login)):
    """Single valve detail view"""
    try:
        store = ValveDataStore()
        # Find valve by job number
        valves = store.get_all_valves()
        valve = next((v for v in valves if v.get("Job Number") == job_number), None)
    except Exception as e:
        valve = None
    
    return templates.TemplateResponse("valve_detail.html", {
        "request": request,
        "user": user,
        "valve": valve,
        "job_number": job_number,
        "app_name": APP_NAME
    })


@app.get("/api/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "ok", "version": "1.0.0", "phase": 1}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
