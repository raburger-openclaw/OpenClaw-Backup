"""
Google Sheets integration for VA QC App
Uses Service Account authentication
"""
import os
from typing import List, Dict, Optional, Any
from google.oauth2 import service_account
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
import json

# OAuth scopes
SCOPES = [
    'https://www.googleapis.com/auth/spreadsheets',
    'https://www.googleapis.com/auth/drive'
]

# Service account key file
SERVICE_ACCOUNT_FILE = os.path.join(os.path.dirname(__file__), 'service-account.json')

class GoogleSheetsClient:
    """Client for Google Sheets API using Service Account"""
    
    def __init__(self):
        self.service = None
        self.drive_service = None
        self._authenticate()
    
    def _authenticate(self):
        """Authenticate with Google using Service Account"""
        if not os.path.exists(SERVICE_ACCOUNT_FILE):
            raise Exception(f"Service account key not found at {SERVICE_ACCOUNT_FILE}")
        
        creds = service_account.Credentials.from_service_account_file(
            SERVICE_ACCOUNT_FILE, scopes=SCOPES
        )
        
        self.service = build('sheets', 'v4', credentials=creds)
        self.drive_service = build('drive', 'v3', credentials=creds)
    
    def read_sheet(self, spreadsheet_id: str, range_name: str) -> List[List[Any]]:
        """Read data from sheet range"""
        try:
            result = self.service.spreadsheets().values().get(
                spreadsheetId=spreadsheet_id,
                range=range_name
            ).execute()
            return result.get('values', [])
        except HttpError as e:
            print(f"Error reading sheet: {e}")
            return []
    
    def append_row(self, spreadsheet_id: str, range_name: str, values: List[Any]) -> bool:
        """Append row to sheet"""
        try:
            body = {'values': [values]}
            self.service.spreadsheets().values().append(
                spreadsheetId=spreadsheet_id,
                range=range_name,
                valueInputOption='USER_ENTERED',
                insertDataOption='INSERT_ROWS',
                body=body
            ).execute()
            return True
        except HttpError as e:
            print(f"Error appending row: {e}")
            return False
    
    def find_spreadsheet_by_name(self, name: str) -> Optional[str]:
        """Find spreadsheet by name in Drive"""
        try:
            results = self.drive_service.files().list(
                q=f"mimeType='application/vnd.google-apps.spreadsheet' and name='{name}'",
                spaces='drive',
                fields='files(id, name)'
            ).execute()
            
            files = results.get('files', [])
            if files:
                return files[0]['id']
            return None
        except Exception as e:
            print(f"Error finding spreadsheet: {e}")
            return None


class ValveDataStore:
    """High-level interface for valve data"""
    
    def __init__(self):
        self.client = GoogleSheetsClient()
        self.spreadsheet_id = self._find_spreadsheet()
    
    def _find_spreadsheet(self) -> str:
        """Find QA sheet"""
        from config import SPREADSHEET_NAME
        sheet_id = self.client.find_spreadsheet_by_name(SPREADSHEET_NAME)
        if not sheet_id:
            raise Exception(f"Spreadsheet '{SPREADSHEET_NAME}' not found")
        return sheet_id
    
    def get_all_valves(self) -> List[Dict]:
        """Get all valve records"""
        headers = self.client.read_sheet(self.spreadsheet_id, "Valves!A1:Z1")
        headers = headers[0] if headers else []
        
        data = self.client.read_sheet(self.spreadsheet_id, "Valves!A2:Z1000")
        
        valves = []
        for row in data:
            if not row or not row[0]:  # Skip empty rows
                continue
            valve = {}
            for i, header in enumerate(headers):
                valve[header] = row[i] if i < len(row) else ""
            valves.append(valve)
        
        return valves
